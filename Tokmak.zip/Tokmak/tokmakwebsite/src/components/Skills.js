import meter1 from "../assets/img/HTML-JS-CSS.png";
import meter2 from "../assets/img/VS.png";
import meter3 from "../assets/img/React.png";
import meter4 from "../assets/img/SQL.png";
import meter5 from "../assets/img/C#.png";
import meter6 from "../assets/img/VSC.png";
import meter7 from "../assets/img/GH.png";
import meter8 from "../assets/img/GB.png";
import meter9 from "../assets/img/ASP-Core.png";
import meter10 from "../assets/img/asp-net-mvc.png";
import Carousel from 'react-multi-carousel';
import 'react-multi-carousel/lib/styles.css';
import arrow1 from "../assets/img/arrow1.svg";
import arrow2 from "../assets/img/arrow2.svg";
import colorSharp from "../assets/img/color-sharp.png"

export const Skills = () => {
  const responsive = {
    superLargeDesktop: {
      // the naming can be any, depends on you.
      breakpoint: { max: 4000, min: 3000 },
      items: 5
    },
    desktop: {
      breakpoint: { max: 3000, min: 1024 },
      items: 3
    },
    tablet: {
      breakpoint: { max: 1024, min: 464 },
      items: 2
    },
    mobile: {
      breakpoint: { max: 464, min: 0 },
      items: 1
    }
  };

  return (
    <section className="skill" id="skills">
        <div className="container">
            <div className="row">
                <div className="col-12">
                    <div className="skill-bx wow zoomIn">
                        <h2>Skills</h2>
                        <p>Here are some of my IT skills. Proficiency in programming languages including Python, C#, and JavaScript. Background in database management, particularly SQL and more.</p>
                        <Carousel responsive={responsive} infinite={true} className="owl-carousel owl-theme skill-slider" autoPlay={true} autoPlaySpeed={2000} keyBoardControl={true} >
                            <div className="item">
                                <img src={meter1} alt="Image" />
                                <h5>HTML, CSS & Javascript</h5>
                            </div>
                            <div className="item">
                                <img src={meter2} alt="Image" />
                                <h5>Visual Studio</h5>
                            </div>
                            <div className="item">
                                <img src={meter6} alt="Image" />
                                <h5>Visual Studio Code</h5>
                            </div>
                            <div className="item">
                                <img src={meter3} alt="Image" /> 
                            </div>
                            <div className="item">
                                <img src={meter4} alt="Image" />                              
                            </div>
                            <div className="item">
                                <img src={meter5} alt="Image" />
                            </div>
                            <div className="item">
                                <img src={meter7} alt="Image" />
                                <h5>Github</h5>
                            </div>
                            <div className="item">
                                <img src={meter8} alt="Image" />
                                <h5>Git Bash</h5>
                            </div>
                            <div className="item">
                                <img src={meter9} alt="Image" />
                            </div>
                            <div className="item">
                                <img src={meter10} alt="Image" />
                                <h5>ASP.NET MVC</h5>
                            </div>
                        </Carousel>
                    </div>
                </div>
            </div>
        </div>
        <img className="background-image-left" src={colorSharp} alt="Image" />
    </section>
  )
}