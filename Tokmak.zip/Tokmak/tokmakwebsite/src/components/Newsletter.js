// import { useState, useEffect } from "react";
// import React from "react";
// import { Col, Row, Alert } from "react-bootstrap";

// export const Newsletter = ({ status, message, onValidated }) => {
//   const [email, setEmail] = useState('');

//   useEffect(() => {
//     if (status === 'success') clearFields();
//   }, [status])

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     email &&
//     email.indexOf("@") > -1 &&
//     onValidated({
//       EMAIL: email
//     })
//   }

//   const clearFields = () => {
//     setEmail('');
//   }

//   return (
//       <Col lg={12}>
//         <div className="newsletter-bx wow slideInUp">
//           <Row>
//             <Col lg={12} md={6} xl={5}>
//               <h3>Download CV<br></br> & cover letter</h3>
//             </Col>
//             <Col md={6} xl={7}>
//               <form onSubmit={handleSubmit}>
//                 <div className="new-email-bx">
//                   <a href="file:///C:/Users/MervanTokmak/Downloads/Mervan%20Tokmak%20CV%20(IT).pdf" download>
//                   <button type="submit">CV</button>
//                   </a>

//                   <a href="file:///C:/Users/MervanTokmak/Downloads/Mervan%20Tokmak%20Personligtbrev%20(IT).pdf" download>
//                   <button type="submit">Cover letter</button>
//                   </a>
//                 </div>
//               </form>
//             </Col>
//           </Row>
//         </div>
//       </Col>
//   )
// }

import React from "react";
import CV from "../assets/docs/Mervan Tokmak CV-IT.pdf";
import PB from "../assets/docs/Mervan Tokmak Personligtbrev-IT.pdf";

export const Newsletter = () => {
  const handleDownloadCV = () => {
    // Skapa en länk till CV-filen
    const downloadLink = document.createElement("a");
    downloadLink.href = CV;
    downloadLink.download = "Mervan_Tokmak_CV.pdf"; // Ange ett namn för den nedladdade filen
    // Klicka på länken för att initiera nedladdningen
    downloadLink.click();
  };

  const handleDownloadCoverLetter = () => {
    // Skapa en länk till personligt brev-filen
    const downloadLink = document.createElement("a");
    downloadLink.href = PB;
    downloadLink.download = "Mervan_Tokmak_Personligt_Brev.pdf"; // Ange ett namn för den nedladdade filen
    // Klicka på länken för att initiera nedladdningen
    downloadLink.click();
  };

  return (
    <div id="CV" className="newsletter-bx wow slideInUp">      
        <h3 className="title">Download CV & cover letter</h3>
      <div className="new-email-bx">
        <button onClick={handleDownloadCV}>CV</button>
        <button onClick={handleDownloadCoverLetter}>Cover letter</button>
      </div>
    </div>
  );
};
